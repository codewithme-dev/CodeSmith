import Connect_With_Database as conn
import random
import string


def generate_random_string(length=8):
    """Generate a random string of fixed length."""
    letters = string.ascii_letters + string.digits
    return ''.join(random.choice(letters) for i in range(length))


def Insert_Credentials(first_name, last_name, username, email, password, account_type):
    """Insert user credentials into the Credentials table."""
    connect = conn.create_database_connection()
    Mycursor = connect.cursor()

    # Insert data into the Credentials table
    Mycursor.execute("""
        INSERT INTO Credentials (first_name, last_name, username, email, password, account_type)
        VALUES (%s, %s, %s, %s, %s, %s)
    """, (first_name, last_name, username, email, password, account_type))

    connect.commit()

    # Get the last inserted ID
    C_id = Mycursor.lastrowid

    # Generate a random sessional ID
    sessional_id = generate_random_string()
    Insert_Sessional_id(sessional_id, C_id)

    # If the account type is Buyer, insert into the Buyer table
    # if account_type == "Buyer":
    #     Mycursor.execute("""
    #         INSERT INTO Buyer (Preferences, Budget, Phone_Number, Email, Location, Sessional_id)
    #         VALUES (%s, %s, %s, %s, %s, %s)
    #     """, ("", 0.0, "", email, "", sessional_id))

    connect.commit()
    print("Credentials inserted successfully")
    Mycursor.close()
    connect.close()


def Insert_Sessional_id(id, C_id):
    """Insert a sessional ID into the Sessional_id table."""
    connect = conn.create_database_connection()
    Mycursor = connect.cursor()

    # Insert data into the Sessional_id table
    Mycursor.execute("""
        INSERT INTO Sessional_id (id, C_id)
        VALUES (%s, %s)
    """, (id, C_id))

    connect.commit()
    print("Sessional_id inserted successfully")
    Mycursor.close()
    connect.close()


def Insert_Real_Estate(Property_Type, Phone_Number, Email, Location, Price, Description, Image, Sessional_id):
    """Insert property details into the Seller table."""
    connect = conn.create_database_connection()
    Mycursor = connect.cursor()

    Mycursor.execute("""
        INSERT INTO Seller (Property_Type, Phone_Number, Email, Location, Price, Description, Image, Sessional_id)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
    """, (Property_Type, Phone_Number, Email, Location, Price, Description, Image, Sessional_id))

    connect.commit()
    Mycursor.close()
    connect.close()


def login_validation(username, password):
    """Validate user login credentials."""
    connect = conn.create_database_connection()
    Mycursor = connect.cursor()

    # Check if the username and password match
    Mycursor.execute("""
        SELECT * FROM Credentials WHERE username = %s AND password = %s
    """, (username, password))
    result = Mycursor.fetchone()

    Mycursor.close()
    connect.close()
    return result is not None


def Existing_User(username, email):
    """Check if the username or email already exists in the Credentials table."""
    connect = conn.create_database_connection()
    Mycursor = connect.cursor()

    # Check if the username or email already exists
    Mycursor.execute("""
        SELECT * FROM Credentials WHERE username = %s OR email = %s
    """, (username, email))
    result = Mycursor.fetchone()

    Mycursor.close()
    connect.close()
    return result is not None


def get_properties():
    """Fetch all properties from the Seller table."""
    connect = conn.create_database_connection()
    Mycursor = connect.cursor(dictionary=True)

    # Fetch properties
    Mycursor.execute("SELECT * FROM Seller")
    properties = Mycursor.fetchall()

    Mycursor.close()
    connect.close()
    return properties


def get_current_buyer_id(username):
    """Fetch the current buyer's ID based on the username."""
    connect = conn.create_database_connection()
    Mycursor = connect.cursor()

    # Fetch buyer ID
    Mycursor.execute("""
        SELECT Buyer.ID
        FROM Buyer
        JOIN Sessional_id ON Buyer.Sessional_id = Sessional_id.id
        JOIN Credentials ON Sessional_id.C_id = Credentials.id
        WHERE Credentials.username = %s AND Credentials.account_type = 'Buyer'
    """, (username,))
    result = Mycursor.fetchone()

    Mycursor.close()
    connect.close()

    if result:
        return result[0]  # Return the buyer ID
    return None


def add_payment(buyer_id, seller_id, amount, payment_method):
    """Add a payment record to the Payment table."""
    connect = conn.create_database_connection()
    Mycursor = connect.cursor()

    # print(buyer_id, seller_id, amount, payment_method)

    # Insert payment record
    Mycursor.execute("""
        INSERT INTO Payment (Buyer_ID, Seller_ID, Amount, Payment_Method)
        VALUES (%s, %s, %s, %s)
    """, (buyer_id, seller_id, amount, payment_method))

    connect.commit()
    payment_id = Mycursor.lastrowid  # Get the last inserted payment ID

    Mycursor.close()
    connect.close()
    return payment_id




def add_transaction(payment_id, status):
    """Add a transaction record to the Transaction table."""
    connect = conn.create_database_connection()
    Mycursor = connect.cursor()

    # Insert transaction record
    Mycursor.execute("""
        INSERT INTO Transaction (Payment_ID, Transaction_Status)
        VALUES (%s, %s)
    """, (payment_id, status))

    connect.commit()
    Mycursor.close()
    connect.close()


def get_account_type(username):
    """Fetch the account type of a user from the Credentials table."""
    connect = conn.create_database_connection()
    Mycursor = connect.cursor()

    # Fetch account type
    Mycursor.execute("""
        SELECT account_type FROM Credentials WHERE username = %s
    """, (username,))
    result = Mycursor.fetchone()

    Mycursor.close()
    connect.close()

    if result:
        return result[0]  # Return the account type
    return None


def get_seller_id(username):
    """Fetch the seller ID for a given username."""
    connect = conn.create_database_connection()
    Mycursor = connect.cursor()

    # Fetch seller ID
    Mycursor.execute("""
        SELECT Sessional_id.id
        FROM Credentials
        JOIN Sessional_id ON Credentials.id = Sessional_id.C_id
        WHERE Credentials.username = %s AND Credentials.account_type = 'Seller'
    """, (username,))
    result = Mycursor.fetchone()

    Mycursor.close()
    connect.close()

    if result:
        return result[0]  # Return the seller ID (Sessional_id)
    return None


def get_seller_id_from_sessional_id(sessional_id):
    connect = conn.create_database_connection()
    # Mycursor = connect.cursor(dictionary=True)
    Mycursor = connect.cursor()
    Mycursor.execute("SELECT ID FROM Seller WHERE Sessional_id = %s", (sessional_id,))
    result = Mycursor.fetchall()
    Mycursor.close()
    connect.close()
    if result:
        return result[0][0]  # Return the first element of the first tuple
    return None

# print(get_seller_id_from_sessional_id("3cBLOK7q"))

def get_properties_by_seller(seller_id):
    """Fetch all properties listed by a specific seller."""
    connect = conn.create_database_connection()
    Mycursor = connect.cursor(dictionary=True)

    Mycursor.execute("""
        SELECT * FROM Seller WHERE Sessional_id = %s
    """, (seller_id,))
    properties = Mycursor.fetchall()

    Mycursor.close()
    connect.close()
    return properties


def get_available_properties():
    """Fetch all properties that are available for buyers."""
    connect = conn.create_database_connection()
    Mycursor = connect.cursor(dictionary=True)

    # Fetch properties where the status is 'Available'
    Mycursor.execute("""
        SELECT id, Property_Type AS type, Phone_Number AS phone_number, Email as email, Location AS location, Price AS price, Description AS description, Image AS image, Sessional_id AS seller_id, Status AS status
        FROM Seller
    """)
    properties = Mycursor.fetchall()

    Mycursor.close()
    connect.close()
    return properties


def update_property_status(property_id, status):
    """Update the status of a property in the Seller table."""
    connect = conn.create_database_connection()
    Mycursor = connect.cursor()

    Mycursor.execute("""
        UPDATE Seller SET Status = %s WHERE ID = %s
    """, (status, property_id))

    connect.commit()
    Mycursor.close()
    connect.close()


def delete_property(property_id):
    """Delete a property from the Seller table."""
    connect = conn.create_database_connection()
    Mycursor = connect.cursor()
    # print(f"Deleting property with ID: {property_id}")

    try:
        # Execute the delete query
        Mycursor.execute("DELETE FROM Seller WHERE ID = %s", (property_id,))
        connect.commit()
        print("Property deleted successfully")
    except Exception as e:
        print(f"Error deleting property: {e}")
        raise
    finally:
        Mycursor.close()
        connect.close()


def add_buyer_details(username, phone, email, location):
    """Add buyer details to the Buyer table."""
    connect = conn.create_database_connection()
    Mycursor = connect.cursor()

    # Fetch the sessional ID for the buyer
    Mycursor.execute("""
        SELECT Sessional_id.id
        FROM Credentials
        JOIN Sessional_id ON Credentials.id = Sessional_id.C_id
        WHERE Credentials.username = %s AND Credentials.account_type = 'Buyer'
    """, (username,))
    result = Mycursor.fetchone()

    if not result:
        Mycursor.close()
        connect.close()
        return None

    sessional_id = result[0]

    # Insert buyer details into the Buyer table
    Mycursor.execute("""
        INSERT INTO Buyer (Phone_Number, Email, Location, Sessional_id)
        VALUES (%s, %s, %s, %s)
    """, (phone, email, location, sessional_id))

    connect.commit()
    buyer_id = Mycursor.lastrowid

    Mycursor.close()
    connect.close()
    return buyer_id

# def get_Amount():
#     """Fetch the price of a property based on its ID."""
#     connect = conn.create_database_connection()
#     Mycursor = connect.cursor()

#     Mycursor.execute("""
#     SELECT SUM(P.Amount)
#     FROM Payment P
#     JOIN Seller S ON P.Seller_ID = S.ID;
# """)
#     result = Mycursor.fetchone()


#     Mycursor.close()
#     connect.close()

#     if result:
#         return result[0]  # Return the price
#     return None

def get_seller_total_payment(username):
    """Fetch the total payment amount received by a seller (by username)."""
    connect = conn.create_database_connection()
    Mycursor = connect.cursor()

    # Get the seller's ID
    Mycursor.execute("""
        SELECT Seller.ID
        FROM Seller
        JOIN Sessional_id ON Seller.Sessional_id = Sessional_id.id
        JOIN Credentials ON Sessional_id.C_id = Credentials.id
        WHERE Credentials.username = %s AND Credentials.account_type = 'Seller'
        LIMIT 1
    """, (username,))
    result = Mycursor.fetchone()
    if not result:
        Mycursor.close()
        connect.close()
        return 0
    seller_id = result[0]

    # Get total payment amount for this seller
    Mycursor.execute("""
        SELECT SUM(Amount) FROM Payment WHERE Seller_ID = %s
    """, (seller_id,))
    total = Mycursor.fetchone()[0]

    Mycursor.close()
    connect.close()
    return total if total else 0

def admin_login_validation(username, password):
    """Validate admin login credentials."""
    connect = conn.create_database_connection()
    Mycursor = connect.cursor()

    # Check if the username and password match
    Mycursor.execute("""
        SELECT * FROM admin WHERE username = %s AND password = %s
    """, (username, password))
    result = Mycursor.fetchone()

    Mycursor.close()
    connect.close()
    return result is not None

def get_admin_Info():
    """Fetch the first admin's information as a dictionary, or None if not found."""
    connect = conn.create_database_connection()
    Mycursor = connect.cursor(dictionary=True)

    Mycursor.execute("SELECT * FROM admin")
    admin_info = Mycursor.fetchall()

    Mycursor.close()
    connect.close()

    if admin_info:
        return admin_info[0]  # Return the first admin as a dict
    else:
        return None

# result = get_admin_Info()
# print(result)

def get_all_buyers():
    """Fetch all buyers from the Buyer table."""
    connect = conn.create_database_connection()
    Mycursor = connect.cursor(dictionary=True)

    Mycursor.execute("SELECT * FROM credentials where account_type = 'Buyer'")
    buyers = Mycursor.fetchall()

    Mycursor.close()
    connect.close()
    return buyers

def get_buyer_info():
    """Fetch all buyer information as a list of dictionaries."""
    connect = conn.create_database_connection()
    Mycursor = connect.cursor(dictionary=True)

    Mycursor.execute("SELECT * FROM buyer")
    buyer_info = Mycursor.fetchall()  # <-- fetchall() returns a list of dicts

    Mycursor.close()
    connect.close()
    return buyer_info

def get_Purchases_info(buyer_Id):
    """Fetch all purchases information for a specific buyer as a list of dictionaries."""
    connect = conn.create_database_connection()
    Mycursor = connect.cursor(dictionary=True)

    Mycursor.execute("""
        SELECT Payment_Method, COUNT(Payment_Method) AS Count
        FROM payment
        WHERE Buyer_ID = %s
        GROUP BY Payment_Method
    """, (buyer_Id,))

    purchases_info = Mycursor.fetchall()

    Mycursor.close()
    connect.close()
    return purchases_info


def get_all_seller():
    """Fetch all buyers from the Buyer table."""
    connect = conn.create_database_connection()
    Mycursor = connect.cursor(dictionary=True)

    Mycursor.execute("SELECT * FROM credentials where account_type = 'Seller'")
    sellers = Mycursor.fetchall()

    Mycursor.close()
    connect.close()
    return sellers

def get_seller_info():
    """Fetch all buyer information as a list of dictionaries."""
    connect = conn.create_database_connection()
    Mycursor = connect.cursor(dictionary=True)

    Mycursor.execute("SELECT * FROM seller")
    seller_info = Mycursor.fetchall()  # <-- fetchall() returns a list of dicts

    Mycursor.close()
    connect.close()
    return seller_info

def get_property_info(seller_Id):
    """Fetch all proverty information for a specific seller as a list of dictionaries."""
    connect = conn.create_database_connection()
    Mycursor = connect.cursor(dictionary=True)

    Mycursor.execute("""
        SELECT COUNT(Payment_Method) AS Count
        FROM payment
        WHERE Seller_ID = %s
    """, (seller_Id,))

    property_info = Mycursor.fetchall()

    Mycursor.close()
    connect.close()
    return property_info