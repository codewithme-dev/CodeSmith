import tkinter as tk
from tkinter import messagebox
import Insert  # Replace with your actual database interaction file
import Login_SignUp


def show_admin_menu(main_frame):
    """Clear the main frame and display the admin menu."""
    for widget in main_frame.winfo_children():
        widget.pack_forget()
    
    info = Insert.get_admin_Info()  # Fetch admin info from the database
    # print("DEBUG: admin info =", info)  # Debug print

    if not info:
        tk.Label(main_frame, text="No admin information available.", font=("Arial", 16)).pack(pady=20)
        return

    tk.Label(main_frame, text="Admin Info", font=("Arial", 16)).pack(pady=10)
    tk.Label(main_frame, text=f"Name: {info['First_Name']} {info['Last_Name']}").pack(pady=10)
    tk.Label(main_frame, text=f"Username: {info['Username']}").pack(pady=10)
    tk.Label(main_frame, text=f"Email: {info['Email']}").pack(pady=10)
    tk.Label(main_frame, text=f"Phone Number: {info['Phone_Number']}").pack(pady=10)
    tk.Button(main_frame, text="View Buyers", command=lambda: buyer_list(main_frame)).pack(pady=10)
    tk.Button(main_frame, text="View Sellers", command=lambda: seller_list(main_frame)).pack(pady=10)
    tk.Button(main_frame, text="Logout", command=lambda: Login_SignUp.logout_(main_frame, main_frame)).pack(pady=10)

def buyer_list(main_frame):
    """Display the list of buyers with scrolling."""
    for widget in main_frame.winfo_children():
        widget.pack_forget()

    buyers = Insert.get_all_buyers()
    if not buyers:
        tk.Label(main_frame, text="No buyers available.", font=("Arial", 16)).pack(pady=20)
        return

    tk.Label(main_frame, text="Buyers List", font=("Arial", 16)).pack(pady=10)

    scrollable = create_scrollable_frame(main_frame)

    count = 0
    for buyer in buyers:
        count += 1
        tk.Label(scrollable, text=f"User {count}: ", font=("Arial", 18)).pack(pady=5)
        tk.Label(scrollable, text=f"Name: {buyer['first_name']} {buyer['last_name']}").pack(pady=5)
        tk.Label(scrollable, text=f"Username: {buyer['username']}").pack(pady=5)
        tk.Label(scrollable, text=f"Email: {buyer['email']}").pack(pady=5)

    tk.Button(main_frame, text="View Buyer Report", command=lambda: buyer_report(main_frame)).pack(pady=10)
    tk.Button(main_frame, text="Back", command=lambda: show_admin_menu(main_frame)).pack(pady=10)
    
def buyer_report(main_frame):
    """Display the buyer report."""
    for widget in main_frame.winfo_children():
        widget.pack_forget()

    buyers = Insert.get_buyer_info()  # Fetch all buyers from the database
    # print(buyers)

    if not buyers:
        tk.Label(main_frame, text="No buyers available.", font=("Arial", 16)).pack(pady=20)
        return


    tk.Label(main_frame, text="Buyer Report", font=("Arial", 16)).pack(pady=10)

    count = 0
    m = 0
    n = -1

    scrollable = create_scrollable_frame(main_frame)
    
    for buyer in buyers:
        count += 1
        tk.Label(scrollable, text=f"User {count}: ", font=("Arial", 18)).pack(pady=5)
        tk.Label(scrollable, text=f"Email: {buyer['Email']}").pack(pady=5)
        tk.Label(scrollable, text=f"Phone Number: {buyer['Phone_Number']}").pack(pady=5)
        tk.Label(scrollable, text=f"Location: {buyer['Location']}").pack(pady=5)
        tk.Label(scrollable, text="-----------------------------").pack(pady=5)
        # buyer_Username = Insert.get_all_buyers()
        buyer_Username = Insert.get_all_buyers()
        buyer_Id = []
        for buy_User in buyer_Username:
         buyer_Id.append(Insert.get_current_buyer_id(buy_User['username']))
        
        m = m + 1
        n = n + 1

        for i in range(n, m):
         Methods = Insert.get_Purchases_info(buyer_Id[i])  # Fetch payment methods and purchase counts
         if not Methods:
          tk.Label(scrollable, text=f"Payment Method: 0").pack(pady=5)
          tk.Label(scrollable, text=f"Number of Purchases: 0").pack(pady=5)
          tk.Label(scrollable, text="-----------------------------").pack(pady=5)
          return
        
         for Method in Methods:
          tk.Label(scrollable, text=f"Payment Method: {Method['Payment_Method']}").pack(pady=5)
          tk.Label(scrollable, text=f"Number of Purchases: {Method['Count']}").pack(pady=5)
          tk.Label(scrollable, text="-----------------------------").pack(pady=5)


    tk.Button(main_frame, text="Back", command=lambda: show_admin_menu(main_frame)).pack(pady=10)


def seller_list(main_frame):
    """Display the list of sellers."""
    for widget in main_frame.winfo_children():
        widget.pack_forget()

    sellers = Insert.get_all_seller()  # Fetch all sellers from the database

    if not sellers:
        tk.Label(main_frame, text="No Sellers available.", font=("Arial", 16)).pack(pady=20)
        return

    tk.Label(main_frame, text="Sellers List", font=("Arial", 16)).pack(pady=10)

    count = 0

    scrollable = create_scrollable_frame(main_frame)

    for seller in sellers:
        count += 1
        tk.Label(scrollable, text=f"Seller {count}: ", font=("Arial", 18)).pack(pady=5)
        tk.Label(scrollable, text=f"Name: {seller['first_name']} {seller['last_name']}").pack(pady=5)
        tk.Label(scrollable, text=f"Username: {seller['username']}").pack(pady=5)
        tk.Label(scrollable, text=f"Email: {seller['email']}").pack(pady=5)
        # tk.Label(main_frame, text=f"Sign Up Date: {buyer['sign_up_date']}").pack(pady=5)

    tk.Button(main_frame, text="View Seller Report", command=lambda: seller_report(main_frame)).pack(pady=10)
    tk.Button(main_frame, text="Back", command=lambda: show_admin_menu(main_frame)).pack(pady=10)

def seller_report(main_frame):
    """Display the seller report."""
    for widget in main_frame.winfo_children():
        widget.pack_forget()

    sellers = Insert.get_seller_info()  # Fetch all sellers from the database

    if not sellers:
        tk.Label(main_frame, text="No seller available.", font=("Arial", 16)).pack(pady=20)
        return


    tk.Label(main_frame, text="Seller Report", font=("Arial", 16)).pack(pady=10)

    count = 0
    m = 0
    n = -1

    scrollable = create_scrollable_frame(main_frame)
    
    for seller in sellers:
        count += 1
        tk.Label(scrollable, text=f"Seller {count}: ", font=("Arial", 18)).pack(pady=5)
        tk.Label(scrollable, text=f"Proverty Type: {seller['Property_Type']}").pack(pady=5)
        tk.Label(scrollable, text=f"Date Added: {seller['Date_Added']}").pack(pady=5)
        tk.Label(scrollable, text="-----------------------------").pack(pady=5)
        
        seller_Username = Insert.get_all_seller()
        seller_Id = []
        for sell_User in seller_Username:
         seller_Id.append(Insert.get_seller_id(sell_User['username']))
        
        m = m + 1
        n = n + 1

        seller_Id_ = []

        for seller_Id__ in seller_Id:
         seller_Id_.append(Insert.get_seller_id_from_sessional_id(seller_Id__))

        for i in range(n, m):
           if i >= len(seller_Id_):
             break
           else:
              Methods = Insert.get_property_info(seller_Id_[i])
              if not Methods:
               tk.Label(scrollable, text=f"Number of Sells: 0").pack(pady=5)
               tk.Label(scrollable, text="-----------------------------").pack(pady=5)
               return
        
              for Method in Methods:
               tk.Label(scrollable, text=f"Number of Sells: {Method['Count']}").pack(pady=5)
               tk.Label(scrollable, text="-----------------------------").pack(pady=5)


    tk.Button(main_frame, text="Back", command=lambda: show_admin_menu(main_frame)).pack(pady=10)

def create_scrollable_frame(parent):
    canvas = tk.Canvas(parent)
    scrollbar = tk.Scrollbar(parent, orient="vertical", command=canvas.yview)
    scrollable_frame = tk.Frame(canvas)

    scrollable_frame.bind(
        "<Configure>",
        lambda e: canvas.configure(
            scrollregion=canvas.bbox("all")
        )
    )

    canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
    canvas.configure(yscrollcommand=scrollbar.set)

    canvas.pack(side="left", fill="both", expand=True)
    scrollbar.pack(side="right", fill="y")

    return scrollable_frame