import tkinter as tk
from tkinter import messagebox, simpledialog
from PIL import Image, ImageTk
import Insert  # Replace with your actual database interaction file
import io
import Login_SignUp

# ...existing code...

def Buyer_UI(root, username):
    search_var = tk.StringVar()

    def load_properties(filtered_properties=None):
        """Load and display available properties for buyers."""
        for widget in main_frame.winfo_children():
            widget.destroy()

        # Use filtered properties if provided, else fetch all
        properties = filtered_properties if filtered_properties is not None else Insert.get_available_properties()

        # --- Search bar ---
        search_frame = tk.Frame(main_frame)
        search_frame.pack(fill="x", pady=5)
        tk.Label(search_frame, text="Search:").pack(side="left", padx=5)
        search_entry = tk.Entry(search_frame, textvariable=search_var, width=30)
        search_entry.pack(side="left", padx=5)
        tk.Button(search_frame, text="Search", command=search_properties).pack(side="left", padx=5)
        tk.Button(search_frame, text="Clear", command=lambda: clear_search()).pack(side="left", padx=5)

        if not properties:
            tk.Label(main_frame, text="No properties available.", font=("Arial", 16)).pack(pady=20)
            def logout():
                Login_SignUp.logout_(root, main_frame)
            logout_btn = tk.Button(main_frame, text="Logout", command=logout, width=15)
            logout_btn.pack(pady=10)
            return
        else:
            def logout():
                Login_SignUp.logout_(root, main_frame)
            logout_btn = tk.Button(main_frame, text="Logout", command=logout, width=15)
            logout_btn.pack(pady=10)

        for property in properties:
            property_frame = tk.Frame(main_frame, bd=2, relief="groove", padx=10, pady=10)
            property_frame.pack(fill="x", pady=10)
            if property["image"]:
                try:
                    image_data = property["image"]
                    image = Image.open(io.BytesIO(image_data))
                    image = image.resize((150, 150))
                    photo = ImageTk.PhotoImage(image)
                    img_label = tk.Label(property_frame, image=photo)
                    img_label.image = photo
                    img_label.pack(side="left", padx=10)
                    # img_label.bind("<Button-1>", lambda e, p=property: show_property_details(p))
                except Exception as e:
                    tk.Label(property_frame, text="Image not available", font=("Arial", 12)).pack(side="left", padx=10)
            details_frame = tk.Frame(property_frame)
            details_frame.pack(side="left", fill="both", expand=True)
            tk.Label(details_frame, text=f"Property Type: {property['type']}", font=("Arial", 12)).pack(anchor="w")
            tk.Label(details_frame, text=f"Phone Number: {property['phone_number']}", font=("Arial", 12)).pack(anchor="w")
            tk.Label(details_frame, text=f"Email: {property['email']}", font=("Arial", 12)).pack(anchor="w")
            tk.Label(details_frame, text=f"Location: {property['location']}", font=("Arial", 12)).pack(anchor="w")
            tk.Label(details_frame, text=f"Price: ${property['price']}", font=("Arial", 12)).pack(anchor="w")
            tk.Label(details_frame, text=f"Status: {property['status']}", font=("Arial", 12)).pack(anchor="w")
            tk.Label(details_frame, text=f"Description: {property['description']}", font=("Arial", 12), wraplength=400).pack(anchor="w")

    def search_properties():
        keyword = search_var.get().lower()
        all_properties = Insert.get_available_properties()
        filtered = [
            p for p in all_properties if
            keyword in str(p.get("type", "")).lower()
            or keyword in str(p.get("location", "")).lower()
            or keyword in str(p.get("description", "")).lower()
            or keyword in str(p.get("email", "")).lower()
        ]
        load_properties(filtered)

    def clear_search():
        search_var.set("")
        load_properties()


    # Clear the root window
    for widget in root.winfo_children():
        widget.destroy()

    # --- SCROLLABLE FRAME SETUP ---
    canvas = tk.Canvas(root)
    scrollbar = tk.Scrollbar(root, orient="vertical", command=canvas.yview)
    scrollable_frame = tk.Frame(canvas)

    scrollable_frame.bind(
        "<Configure>",
        lambda e: canvas.configure(
            scrollregion=canvas.bbox("all")
        )
    )

    canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
    canvas.configure(yscrollcommand=scrollbar.set)

    canvas.pack(side="left", fill="both", expand=True)
    scrollbar.pack(side="right", fill="y")

    def _on_mousewheel(event):
        canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")

    canvas.bind_all("<MouseWheel>", _on_mousewheel)

    # Use scrollable_frame as main_frame
    main_frame = scrollable_frame

    # Title
    tk.Label(main_frame, text="Available Properties", font=("Arial", 20, "bold")).pack(pady=10)

    # Load Properties
    load_properties()
# ...existing code...
