import tkinter as tk
from tkinter import messagebox
import Login_SignUp
import Buyer
import Seller
import Insert  # Assuming Insert contains database interaction functions
# import Admin  # Assuming Admin contains admin functionalities

def sign_up():
    """Clear the main frame and show the Sign-Up form."""
    for widget in main_frame.winfo_children():
        widget.pack_forget()
    Login_SignUp.SignUp(root, main_frame)

def login():
    """Clear the main frame and show the Login form."""
    def after_login(root, username):
        """Handle actions after a successful login."""
        # Fetch account type from the database
        account_type = Insert.get_account_type(username)  # Replace with your DB function to fetch account type
        seller_id = Insert.get_seller_id(username)  # Replace with your DB function to fetch seller ID

        if account_type == "Buyer":
            # Show Buyer UI if account type is Buyer
            Buyer.Buyer_UI(root, username)  # Buyer interface includes "View Properties"
        elif account_type == "Seller":
            # Show Seller UI if account type is Seller
            Seller.Seller_UI(root, seller_id)  # Seller interface includes "Add Property"
        else:
            # Show a message if the account type is invalid
            messagebox.showinfo("Info", "Invalid account type. Please contact support.")

    # Clear the main frame and show the Login form
    for widget in main_frame.winfo_children():
        widget.pack_forget()
    Login_SignUp.Login(root, main_frame, after_login)  # Pass the after_login callback

def admin_login():
    """Clear the main frame and show the Admin Login form."""
    for widget in main_frame.winfo_children():
        widget.pack_forget()
    Login_SignUp.Admin_Login(root, main_frame)  # Call the admin menu function from Admin module

def show_main_menu():
    """Clear the main frame and display the main menu."""
    for widget in main_frame.winfo_children():
        widget.pack_forget()

    # Add the Sign Up button
    sign_up_btn = tk.Button(main_frame, text="Sign Up", command=sign_up, width=15)
    sign_up_btn.pack(pady=10)

    # Add the Login button
    login_btn = tk.Button(main_frame, text="Login", command=login, width=15)  # Call login function
    login_btn.pack(pady=10)

    Admin_btn = tk.Button(main_frame, text="Admin", command=admin_login, width=15)
    Admin_btn.pack(pady=10)

if __name__ == "__main__":
    # Create the main window
    root = tk.Tk()
    root.title("Real Estate App")
    root.geometry("400x300")  # Set the window size

    # Create a frame to hold the content
    main_frame = tk.Frame(root)
    main_frame.pack(fill="both", expand=True)

    # Show the main menu
    show_main_menu()

    # Run the application
    root.mainloop()