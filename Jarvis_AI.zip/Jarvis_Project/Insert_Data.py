import Connect_With_Database as conn
import os
import Face
import random
import string
import base64
from io import BytesIO
from PIL import Image


def generate_random_id(length=8):
    chars = string.ascii_lowercase + string.digits
    return ''.join(random.choices(chars, k=length))

def insert_data_to_credentials(first_name, last_name, username, email, password, face_image_path=None, model_path=None):
    """Insert data into the Credentials table with optional Face Image and Model Path."""
    connect = None
    cursor = None

    try:
        # Create a database connection
        connect = conn.create_database_connection()
        cursor = connect.cursor()
        cursor.execute("USE Jarvis_DB")

        # Initialize defaults
        face_image = None
        model_path_db = None

        # Handle face image if path is provided
        if face_image_path and os.path.exists(face_image_path):
            with open(face_image_path, 'rb') as file:
                face_image = file.read()

        # Handle trained model path if it exists
        if model_path and os.path.exists(model_path):
            model_path_db = model_path  # Save as string path in DB

        # Insert data into the Credentials table
        sql = """
            INSERT INTO Credentials (
                First_Name, Last_Name, Username, Email, Password, Face_Recognition, Trained_Model
            ) VALUES (%s, %s, %s, %s, %s, %s, %s)
        """
        values = (first_name, last_name, username, email, password, face_image, model_path_db)
        cursor.execute(sql, values)

        # Commit the transaction
        connect.commit()

        c_id = cursor.lastrowid
        # print(f"Last inserted ID: {c_id}")

        session_id(generate_random_id(), c_id)

        print("✅ Data inserted successfully into Credentials table.")
        print("✅ Sign-Up successfully!")
        Face.speak("Sign-Up successfully!")
        

    except Exception as e:
        print(f"❌ Error while inserting data: {e}")
        if connect:
            connect.rollback()
    finally:
        if cursor:
            cursor.close()
        if connect:
            connect.close()


def Existing_User(username, email):
    """Check if the username or email already exists in the Credentials table."""
    connect = conn.create_database_connection()
    Mycursor = connect.cursor()

    sql = "SELECT * FROM Credentials WHERE Username = %s OR Email = %s"
    val = (username, email)
    Mycursor.execute(sql, val)

    existing_user = Mycursor.fetchone()

    Mycursor.close()
    connect.close()

    return existing_user is not None

def validate_login(username, password):
    """Validate user login credentials."""
    connect = conn.create_database_connection()
    Mycursor = connect.cursor()

    sql = "SELECT * FROM Credentials WHERE Username = %s AND Password = %s"

    val = (username, password)
    Mycursor.execute(sql, val)

    user = Mycursor.fetchone()

    Mycursor.close()
    connect.close()

    return user is not None

def forgot_password(username,password):
    """Fetch the password for the given username."""
    connect = conn.create_database_connection()
    Mycursor = connect.cursor()

    sql = "Update Credentials set Password = %s where Username = %s"
    val = (password, username)
    Mycursor.execute(sql, val)
    connect.commit()
    Mycursor.close()




def session_id(id, c_id):
    """Insert session ID into the Sessional_id table."""
    try:
        connect = conn.create_database_connection()
        Mycursor = connect.cursor()

        # c_id = Mycursor.lastrowid
        # print(f"Last inserted ID: {c_id}")

        sql = """INSERT INTO Sessional_id (id, C_id) 
                 VALUES (%s, %s)"""
        val = (id, c_id)

        Mycursor.execute(sql, val)
        connect.commit()

        Mycursor.close()
        connect.close()

        print("Session ID inserted successfully.")

    except Exception as e:
        print(f"Error while inserting session ID: {e}")
        if connect:
            connect.rollback()
        if Mycursor:
            Mycursor.close()
        if connect:
            connect.close()



def History_Chat(user_chat, bot_chat):
    """Insert chat history into the History table."""
    try:
        connect = conn.create_database_connection()
        Mycursor = connect.cursor()

        try:
            with open("session.txt", "r") as f:
                username = f.read().strip()
        except FileNotFoundError:
            print("No logged-in user found. Please log in.")
            return

        query = """
          SELECT id 
         FROM Sessional_id 
         WHERE C_id = (SELECT id FROM Credentials WHERE Username = %s)
               """
        Mycursor.execute(query, (username,))
        result = Mycursor.fetchone()

        if result:
            sessional_id = result[0]

        sql = """INSERT INTO History (User_Chat, Bot_Chat, Sessional_id) 
                 VALUES (%s, %s, %s)"""
        val = (user_chat, bot_chat, sessional_id)

        Mycursor.execute(sql, val)
        connect.commit()

        Mycursor.close()
        connect.close()

        print("Chat history inserted successfully.")

    except Exception as e:
        print(f"Error while inserting chat history: {e}")
        if connect:
            connect.rollback()
        if Mycursor:
            Mycursor.close()
        if connect:
            connect.close()


def show_history():
    """Display chat history for the current logged-in user."""
    try:
        # Step 1: Read username from session file
        try:
            with open("session.txt", "r") as f:
                username = f.read().strip()
        except FileNotFoundError:
            print("❌ No logged-in user. Please log in first.")
            return

        # Step 2: Connect to the database
        connect = conn.create_database_connection()
        Mycursor = connect.cursor()

        # Step 3: Get sessional ID(s) for this user
        query = """
            SELECT h.User_Chat, h.Bot_Chat, h.date_time
            FROM History h
            JOIN Sessional_id s ON h.Sessional_id = s.id
            JOIN Credentials c ON s.C_id = c.id
            WHERE c.Username = %s
            ORDER BY h.date_time ASC
        """
        Mycursor.execute(query, (username,))
        rows = Mycursor.fetchall()

        if rows:
            print(f"\n📜 Chat History for '{username}':\n")
            for i, row in enumerate(rows, 1):
                if row[1].startswith("[IMAGE_BASE64_START]"):
                    # Extract the base64 image data
                    img_data = row[1].split("[IMAGE_BASE64_START]")[1]
                    # img = row[1]
                    image_data = base64.b64decode(img_data)
                    image = Image.open(BytesIO(image_data))
                    image.show()  # Display the image
                else:
                    print(f"{i}. You: {row[0]}")
                    print(f"   Jarvis: {row[1]}")
                    print(f"   ⏰ Time: {row[2]}\n")
        else:
            print("ℹ️ No chat history found for this user.")

    except Exception as e:
        print(f"❌ Error retrieving chat history: {e}")
    finally:
        if Mycursor:
            Mycursor.close()
        if connect:
            connect.close()

def clear_history():
    """Clear chat history for the current logged-in user."""
    try:
        # Step 1: Read username from session file
        try:
            with open("session.txt", "r") as f:
                username = f.read().strip()
        except FileNotFoundError:
            print("❌ No logged-in user. Please log in first.")
            return

        # Step 2: Connect to the database
        connect = conn.create_database_connection()
        Mycursor = connect.cursor()

        # Step 3: Get sessional ID(s) for this user
        query = """
            DELETE FROM History 
            WHERE Sessional_id IN (SELECT id FROM Sessional_id WHERE C_id = (SELECT id FROM Credentials WHERE Username = %s))
        """
        Mycursor.execute(query, (username,))

        # Commit the changes
        connect.commit()

        print("✅ Chat history cleared successfully.")

    except Exception as e:
        print(f"❌ Error clearing chat history: {e}")
    finally:
        if Mycursor:
            Mycursor.close()
        if connect:
            connect.close()










# def Face_Recognition(username):
#     """Fetch face recognition data for the given username."""
#     connect = conn.create_database_connection()
#     Mycursor = connect.cursor()

#     sql = "SELECT Face_Recognition FROM Credentials WHERE Username = %s"
#     val = (username,)
#     Mycursor.execute(sql, val)

#     face_data = Mycursor.fetchone()

#     Mycursor.close()
#     connect.close()

#     return face_data[0] if face_data else None