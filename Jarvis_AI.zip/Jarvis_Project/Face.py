import cv2
import os
import numpy as np
import pyttsx3
import Connect_With_Database as conn

# ========== Speak Function ==========
engine = pyttsx3.init()

def speak(text):
    print(f"🔈 {text}")
    engine.say(text)
    engine.runAndWait()


# ========== 1. Create dataset ==========
def create_dataset(username):
    if not os.path.exists("faces"):
        os.makedirs("faces")

    user_folder = f"faces/{username}"
    if not os.path.exists(user_folder):
        os.makedirs(user_folder)

    image_path = os.path.join(user_folder, "1.jpg")
    # cv2.imwrite(image_path, frame)    

    face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
    cap = cv2.VideoCapture(0)
    count = 0

    speak("Capturing your face. Please look into the camera.")

    while True:
        ret, frame = cap.read()
        if not ret:
            continue

        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = face_cascade.detectMultiScale(gray, 1.3, 5)

        for (x, y, w, h) in faces:
            count += 1
            face = gray[y:y+h, x:x+w]
            cv2.imwrite(f"{user_folder}/{count}.jpg", face)

            cv2.rectangle(frame, (x, y), (x+w, y+h), (255, 0, 0), 2)

        cv2.imshow('Capturing Face', frame)

        if cv2.waitKey(1) == ord('q') or count >= 20:  # Take 20 images
            break

    cap.release()
    cv2.destroyAllWindows()
    speak("Face capture complete.")
    print("✅ Face capture complete.")
    return image_path


# ========== 2. Train model ==========
def train_model(username):
    faces = []
    labels = []

    user_folder = f"faces/{username}"
    label = 0

    for filename in os.listdir(user_folder):
        img_path = os.path.join(user_folder, filename)
        img = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)
        faces.append(img)
        labels.append(label)

    recognizer = cv2.face.LBPHFaceRecognizer_create()
    recognizer.train(faces, np.array(labels))

    if not os.path.exists('model'):
        os.makedirs('model')
    recognizer.save(f"model/{username}_model.yml")
    path = f"model/{username}_model.yml"

    speak("Model trained successfully.")
    print("✅ Model trained and saved.")
    return path


# ========== 3. Face Unlock ==========
def face_unlock(username):
    # model_path = f"model/{username}_model.yml"

    connect = conn.create_database_connection()
    Mycursor = connect.cursor()

    query = "SELECT Trained_Model FROM Credentials WHERE Username = %s"
    Mycursor.execute(query, (username,))
    model_path_db = Mycursor.fetchone()  # e.g., ('admin',)

    if model_path_db:
     model_name = model_path_db[0]  # Extract the string from tuple
    #  print("Model name from DB:", model_name)

    #  model_path = f"model/{model_name}_model.yml"

     model_path = model_name
    #  print("Full model path:", model_path)
    else:
     print("❌ No model path found for this username.")
     speak("No model path found for this username.")
     model_path = "model/unknown_model.yml"  # Default or error model path

    if not model_path:
        model_path = "model/unknown_model.yml"  # Default or error model path

    if not os.path.exists(model_path):
        speak("No model found. Please register first.")
        print("❌ No model found. Please register first.")
        return

    recognizer = cv2.face.LBPHFaceRecognizer_create()
    recognizer.read(model_path)

    face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
    cap = cv2.VideoCapture(0)

    speak("Face lock active. Please show your face to unlock.")

    match_found = False
    timeout_counter = 0

    while True:
        ret, frame = cap.read()
        if not ret:
            continue

        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = face_cascade.detectMultiScale(gray, 1.3, 5)

        for (x, y, w, h) in faces:
            face = gray[y:y+h, x:x+w]
            label, confidence = recognizer.predict(face)

            if label == 0 and confidence < 50:
                match_found = True
                color = (0, 255, 0)
                text = "Unlocked ✅"
            else:
                color = (0, 0, 255)
                text = "Not Matched ❌"

            cv2.rectangle(frame, (x, y), (x+w, y+h), color, 2)
            cv2.putText(frame, text, (x, y-10), cv2.FONT_HERSHEY_SIMPLEX, 0.8, color, 2)

        cv2.imshow('Face Unlock', frame)

        if match_found:
            speak("Face matched. Access granted!")
            print("✅ Face matched. Access granted!")
            break

        if cv2.waitKey(1) == ord('q'):
            speak("Face unlock cancelled.")
            print("🔒 Access denied.")
            break

        timeout_counter += 1
        if timeout_counter > 300:
            speak("Timeout. Face not matched.")
            print("⏳ Timeout. Face not matched.")
            break

    cap.release()
    cv2.destroyAllWindows()
    return match_found


# ========== Main Program ==========
# print("Welcome to Face Lock 🔒")
# speak("Welcome to Face Lock.")

# while True:
#     choice = input("Do you want to (1) Register or (2) Unlock or (3) Exit? ")

#     if choice == '1':
#         username = input("Enter your username: ")
#         create_dataset(username)
#         train_model(username)

#     elif choice == '2':
#         username = input("Enter your username: ")
#         face_unlock(username)

#     elif choice == '3':
#         speak("Goodbye. See you next time.")
#         print("Goodbye!")
#         break

#     else:
#         speak("Invalid choice. Please try again.")
#         print("❌ Invalid choice. Please try again.")


# create_dataset("n")
# train_model("n")
# face_unlock("n")






















# import cv2
# import os
# import pyttsx3
# import numpy as np
# import face_recognition
# import Connect_With_Database as conn

# def speak(text):
#     """Function to convert text to speech."""
#     engine = pyttsx3.init()
#     engine.say(text)
#     engine.runAndWait()

# def capture_face_data(username):
#     # user_folder = []
#     face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
#     cap = cv2.VideoCapture(0)

#     # for i in range(1, 11):
#     #     user_folder.append(f"faces/{username}/{i}.jpg")
#     user_folder = f"faces/{username}"

#     if not os.path.exists(user_folder):
#       os.makedirs(user_folder)

# # Now you can safely save face images inside 'faces/username'!
#     image_path = os.path.join(user_folder, "1.jpg")
#     # cv2.imwrite(image_path, frame)

#     count = 0
#     speak("Please look into the camera... capturing your face.")
#     while True:
#         ret, frame = cap.read()
#         gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
#         faces = face_cascade.detectMultiScale(gray, 1.3, 5)

#         for (x,y,w,h) in faces:
#             count += 1
#             face = gray[y:y+h, x:x+w]
#             cv2.imwrite(f"{user_folder}/{count}.jpg", face)
#             cv2.rectangle(frame, (x,y), (x+w,y+h), (255,0,0), 2)

#         cv2.imshow('Capturing Face', frame)
#         if cv2.waitKey(1) & 0xFF == ord('q') or count >= 10:
#             break

#     cap.release()
#     cv2.destroyAllWindows()
#     speak("Face captured successfully!")
#     return image_path


# def validate_face_login(username):
#     """Validate face data from database and login by face (only exact match)."""
#     try:
#         connect = conn.create_database_connection()
#         Mycursor = connect.cursor()

#         # Fetch face image data from database
#         query = "SELECT Face_Recognition FROM Credentials WHERE Username = %s"
#         Mycursor.execute(query, (username,))
#         result = Mycursor.fetchone()

#         if result and result[0]:
#             print("Face data found in database. Verifying face...")
        
    
#             # with open(f"temp_face_{username}.jpg", 'rb') as file:
#             #  face_image = file.read()
#             #  print(face_image)
#             # Save the image temporarily
#             temp_image_path = f"temp_face_{username}.jpg"
#             with open(temp_image_path, 'wb') as file:
#                 file.write(result[0])
#                 with open(f"temp_face_{username}.jpg", 'rb') as file:
#                  face_image = file.read()
#                  print(face_image)

#             # Load known face (grayscale)
#             known_face_img = cv2.imread(temp_image_path, cv2.IMREAD_GRAYSCALE)

#             if known_face_img is None:
#                 speak("Stored face data is invalid. Please register again.")
#                 print("❌ Stored face could not be loaded.")
#                 os.remove(temp_image_path)
#                 return False

#             # Face detection
#             face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
#             faces = face_cascade.detectMultiScale(known_face_img, scaleFactor=1.3, minNeighbors=5)

#             if len(faces) == 0:
#                 speak("Stored face data does not contain a recognizable face.")
#                 print("❌ No face detected in stored image.")
#                 os.remove(temp_image_path)
#                 return False

#             (x, y, w, h) = faces[0]
#             known_face = known_face_img[y:y+h, x:x+w]  # Crop the face

#             # Initialize recognizer
#             recognizer = cv2.face.LBPHFaceRecognizer_create()
#             recognizer.train([known_face], np.array([0]))  # Label 0 for the user

#             # Start webcam
#             cap = cv2.VideoCapture(0)

#             speak("Camera opened. Please look into the camera.")

#             match_found = False
#             timeout_counter = 0

#             # f = capture_face_data("n")
#             # if f==face_image:
#             #     match_found = True

#             while True:
#                 ret, frame = cap.read()
#                 if not ret:
#                     continue

#                 gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
#                 faces = face_cascade.detectMultiScale(gray, 1.3, 5)

#                 for (x, y, w, h) in faces:
#                     face = gray[y:y+h, x:x+w]

#                     try:
#                         label, confidence = recognizer.predict(face)
#                         print(label,confidence)

                       


#                         if label == 0 and confidence < 50:  # Tighter confidence
#                             match_found = True
#                             color = (0, 255, 0)
#                         else:
#                             color = (0, 0, 255)

#                         cv2.rectangle(frame, (x, y), (x+w, y+h), color, 2)

#                     except Exception as e:
#                         print(f"Prediction error: {e}")

#                 cv2.imshow('Face Login', frame)

#                 if match_found:
#                     speak("Face matched. Login successful.")
#                     print("✅ Face matched. Login successful.")
#                     break

#                 if cv2.waitKey(1) & 0xFF == ord('q'):
#                     speak("Login cancelled by user.")
#                     break

#                 timeout_counter += 1
#                 if timeout_counter > 300:
#                     speak("Timeout. Face not matched.")
#                     break

#             cap.release()
#             cv2.destroyAllWindows()
#             os.remove(temp_image_path)

#             return match_found

#         else:
#             speak("No face data found for this username.")
#             print("❌ No face data found for this username.")
#             return False

#     except Exception as e:
#         print(f"Error during face validation: {e}")
#         speak("Something went wrong during face validation.")
#         return False

# validate_face_login("n")  # Replace with actual username for testing


# # username = input("Enter your name: ")
# # capture_face_data(username)
# # speak("Face data capture complete.")

# # def vaildate_face_data(username):
# #     user_folder = f"faces/{username}"
# #     if os.path.exists(user_folder):
# #         speak("Face data already exists.")
# #         return True
# #     else:
# #         speak("No face data found. Please capture your face data first.")
# #         return False

# # def validate_face_login(username):
# #     """Validate face data from database and login by face."""
# #     try:
# #         connect = conn.create_database_connection()
# #         Mycursor = connect.cursor()

# #         # Fetch face image data from database
# #         query = "SELECT Face_Recognition FROM Credentials WHERE Username = %s"
# #         Mycursor.execute(query, (username,))
# #         result = Mycursor.fetchone()

# #         if result and result[0]:
# #             print("Face data found in database. Verifying face...")

# #             # Save the image temporarily
# #             with open(f"temp_face_{username}.jpg", 'wb') as file:
# #                 file.write(result[0])

# #             # Load the known face
# #             known_image = face_recognition.load_image_file(f"temp_face_{username}.jpg")
# #             known_face_encoding = face_recognition.face_encodings(known_image)[0]

# #             # Open webcam and capture live image
# #             cap = cv2.VideoCapture(0)
# #             ret, frame = cap.read()
# #             cap.release()

# #             if not ret:
# #                 speak("Failed to capture image from webcam.")
# #                 return False

# #             # Encode the captured face
# #             unknown_face_encodings = face_recognition.face_encodings(frame)

# #             if len(unknown_face_encodings) == 0:
# #                 speak("No face detected. Try again.")
# #                 return False

# #             # Compare faces
# #             match_results = face_recognition.compare_faces([known_face_encoding], unknown_face_encodings[0])

# #             # Remove temporary file
# #             os.remove(f"temp_face_{username}.jpg")

# #             if match_results[0]:
# #                 speak("Face matched. Login successful.")
# #                 print("✅ Face matched. Login successful.")
# #                 return True
# #             else:
# #                 speak("Face did not match. Login failed.")
# #                 print("❌ Face did not match. Login failed.")
# #                 return False

# #         else:
# #             speak("No face data found for this username.")
# #             print("No face data found for this username.")
# #             return False

# #     except Exception as e:
# #         print(f"Error during face validation: {e}")
# #         speak("Something went wrong during face validation.")
# #         return False