# import Connect_With_Database as conn
import Insert_Data
import Face
import pyttsx3


# Save logged-in username to a file
def store_username(username):
    with open("session.txt", "w") as f:
        f.write(username)


def speak(text):
    """Function to convert text to speech."""
    engine = pyttsx3.init()
    engine.say(text)
    engine.runAndWait()

def sign_up():
    """Function to handle user sign-up."""
    print("Welcome to the Sign-Up page!")
    speak("Welcome to the Sign-Up page!")
    first_name = input("Enter your First Name: ")
    last_name = input("Enter your Last Name: ")
    username = input("Enter your Username: ")
    email = input("Enter your Email: ")
    password = input("Enter your Password: ")
    
    if not username or not email or not password:
        print("Username, Email, and Password are required fields.")
        speak("Username, Email, and Password are required fields.")
        return
    
    # Check if username or email already exists
    # connect = conn.create_database_connection()
    # Mycursor = connect.cursor()
    # Mycursor.execute("SELECT * FROM Credentials WHERE Username = %s OR Email = %s", (username, email))
    # existing_user = Mycursor.fetchone()
    # Mycursor.close()
    # connect.close()

    existing_user = Insert_Data.Existing_User(username, email)

    if existing_user:
        print("Username or Email already exists. Please try again.")
        speak("Username or Email already exists. Please try again.")
        return
    
    if not first_name or not last_name:
        print("First Name and Last Name are required fields.")
        speak("First Name and Last Name are required fields.")
        return
    if email.count('@') != 1 or email.count('.') < 1:
        print("Invalid email format.")
        speak("Invalid email format.")
        return
    if email.endswith in ('@gmail.com', '@yahoo.com', '@outlook.com'):
        print("Email domain is not allowed.")
        speak("Email domain is not allowed.")
        return

    if len(password) < 8:
        print("Password must be at least 8 characters long.")
        speak("Password must be at least 8 characters long.")
        return
    if not any(char.isdigit() for char in password):
        print("Password must contain at least one digit.")
        speak("Password must contain at least one digit.")
        return
    if not any(char.isalpha() for char in password):
        print("Password must contain at least one letter.")
        speak("Password must contain at least one letter.")
        return
    
    if not any(char in "!@#$%^&*()-_+=<>?{}[]|:;\"'`~" for char in password):
        print("Password must contain at least one special character.")
        speak("Password must contain at least one special character.")
        return
    
    if len(password) > 20:
        print("Password must not exceed 20 characters.")
        speak("Password must not exceed 20 characters.")
        return
    

    # Optional: Ask for face image path
    # face_image_path = input("Enter the path to your face image (or press Enter to skip): ")

    speak("Do you want to capture your face data? Enter yes or no")
    Check = input("Do you want to capture your face data? (yes/no): ").strip().lower()
    if Check == 'yes':
        print("Capturing face data...")
        face_image_path = Face.create_dataset(username)
        path = Face.train_model(username)
        # print(path)
        if not face_image_path:
            print("Face data capture failed.")
            return
    else: 
        print("Skipping face data capture.")
        speak("Skipping face data capture.")
        path = None
        face_image_path = None


    # face_image_path = Face.capture_face_data(username)
    # if not face_image_path:
    #     face_image_path = None

    # Insert data into the database
    
    Insert_Data.insert_data_to_credentials(first_name, last_name, username, email, password, face_image_path, path)
    # Insert_Data.session_id(generate_random_id())
    # print("Sign-Up successful!")


# sign_up()


def login():
    """Function to handle user login."""
    print("Welcome to the Login page!")
    speak("Welcome to the Login page!")

    speak("Do you want to login with your face data? Enter yes or no")
    choice = input("Do you want to login with your face data? (yes/no): ").strip().lower()
    if choice == 'yes':
        username = input("Enter your Username: ")
        print("Capturing face data...")
        # face_image_path = Face.capture_face_data(username)
        face_image_path = Face.face_unlock(username)
        if face_image_path:
            print("Face data captured successfully!")
            speak("Face data captured successfully!")
            print("Login successfully!")
            speak("Login successfully!")
            store_username(username)
            return True
        else:
            print("Face data capture failed.")
            speak("Face data capture failed.")
            return
    else:
        print("Skipping face data capture.")
        speak("Skipping face data capture.")
        face_image_path = None

    if not face_image_path:
        # If face data capture is skipped, ask for username and password    
        username = input("Enter your Username: ")
        password = input("Enter your Password: ")

        if not Insert_Data.Existing_User:
          print("No user found. Please sign up first.")
          speak("No user found. Please sign up first.")
          return

        if not username or not password:
         print("Username and Password are required fields.")
         speak("Username and Password are required fields.")
         return

        user = Insert_Data.validate_login(username, password)

        if user:
         print("Login successfully!")
         speak("Login successfully!")
         store_username(username)
         return True
         # Proceed with the application logic after successful login
        else:
          print("Invalid Username or Password. Please try again.")  
          speak("Invalid Username or Password. Please try again.") 

    


# login()        