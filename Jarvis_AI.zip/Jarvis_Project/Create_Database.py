import Connect_With_Database as conn


def Create_Database():
    connect = conn.create_database_connection()
    Mycursor = connect.cursor()
    Mycursor.execute("CREATE DATABASE IF NOT EXISTS Jarvis_DB")
    print("Database created successfully")
    Mycursor.execute("USE Jarvis_DB")
    Mycursor.close()
    connect.close()

def Create_Table():
    connect = conn.create_database_connection()
    Mycursor = connect.cursor()

    # Create Credentials table
    Mycursor.execute("""
        CREATE TABLE IF NOT EXISTS Credentials (
            id INT AUTO_INCREMENT PRIMARY KEY,
            First_Name VARCHAR(255),
            Last_Name VARCHAR(255),
            Username VARCHAR(255) UNIQUE,
            Email VARCHAR(255) UNIQUE,
            Password VARCHAR(255),
            Face_Recognition LONGBLOB DEFAULT NULL,
            Trained_Model VARCHAR(255) DEFAULT NULL
        )
    """)

    # Create Sessional_id table
    Mycursor.execute("""
        CREATE TABLE IF NOT EXISTS Sessional_id (
            id VARCHAR(255) PRIMARY KEY,
            C_id INT,
            FOREIGN KEY (C_id) REFERENCES Credentials(id)
        )
    """)

    # Create History table (linking by sessional_id instead of text)
    Mycursor.execute("""
        CREATE TABLE IF NOT EXISTS History (
            id INT AUTO_INCREMENT PRIMARY KEY,
            User_Chat LONGTEXT,
            Bot_Chat LONGTEXT,
            Sessional_id VARCHAR(255),
            date_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (Sessional_id) REFERENCES Sessional_id(id)
        )
    """)

    print("Tables created successfully")
    Mycursor.close()
    connect.close()



# Create_Database()
# Create_Table()