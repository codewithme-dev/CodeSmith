import speech_recognition as sr
import pyttsx3
import webbrowser
import wikipedia
import wolframalpha
import os
import time
import pyautogui
import base64
from io import BytesIO
import Login_Sign_Up
import Insert_Data

# import Connect_With_Database as conn


# connect = conn.create_database_connection()
# print("Database connection established.",connect)


app_id = "J4EH6W-WLQT52LG53"  # WolframAlpha App ID

# cmd = ["what is", "who is", "where is", "when is", "how to"]


def clear_screen():
    """Clear the console screen."""
    os.system('cls' if os.name == 'nt' else 'clear')


def speak(text):
    """Function to convert text to speech."""
    engine = pyttsx3.init()
    engine.say(text)
    engine.runAndWait()

def processCommand(command):
    """Process the voice command and execute corresponding actions."""
    command = command.lower()

    # Handle 'open' command
    if command and "open" in command.lower():
        open_query = command.replace("open", "").strip()
        new_query = open_query.split(" ")[0]
        # print(new_query)
        webbrowser.open(f"https://www.{new_query}.com")
        speak(f"Opening {new_query}")
    
    # Handle 'search' command
    elif command and "search" in command.lower():
        # speak("What would you like to search for?")
        # print("Listening for search query...")
        search_query = command.replace("search", "").strip()[1:]

        # search_query = listen_command()

        try:
            result = wikipedia.summary(search_query, sentences=2)
            print(result)
            speak(result)
            Insert_Data.History_Chat(search_query, result)
        except wikipedia.exceptions.DisambiguationError:
            speak("Multiple topics found, please be more specific.")
        # except wikipedia.exceptions.HTTPError:
        #     speak("There was an error with the request. Please try again.")
        except wikipedia.exceptions.PageError:
            speak("Sorry, I couldn't find information on that topic.")
            speak("Would you like me to search on Chatgpt instead?")
            speak("Please say yes or no.")
            response = listen_command()
            if response and "yes" in response.lower():
                webbrowser.open(f"https://www.chatgpt.com/search?q={search_query}")
                speak("Searching on Chatgpt.")
            else:
                speak("Okay, let me know if you need anything else.")
        except Exception as e:
            speak(f"An error occurred: {e}")
            
    elif command and "show history" in command.lower():
        # speak("Fetching your chat history.")
        print("Fetching your chat history...")
        Insert_Data.show_history()
        speak("Here is your chat history.")
    elif command and "clear screen" in command.lower():
        # speak("Clearing the screen.")
        print("Clearing the screen...")
        clear_screen()
        speak("Screen cleared.") 
    elif command and "clear history" in command.lower():
        # speak("Clearing your chat history.")
        print("Clearing your chat history...")
        Insert_Data.clear_history()
        speak("Chat history cleared.")
    elif command and (cmd := command.lower()):
     if "date" in cmd and "time" in cmd and (t := time.strftime("%H:%M:%S")) and (d := time.strftime("%Y-%m-%d")):
        print("🕒📅 Showing time and date...")
        print(f"The current time is {t} and the date is {d}.")
        speak(f"The current time is {t} and the date is {d}.")
     elif "time" in cmd and (t := time.strftime("%H:%M:%S")):
        print("🕒 Showing time only...")
        print(f"The current time is {t}.")
        speak(f"The current time is {t}.")
     elif "date" in cmd and (d := time.strftime("%Y-%m-%d")):
        print("📅 Showing date only...")
        print(f"Today's date is {d}.")
        speak(f"Today's date is {d}.") 
    else:
        speak("Sorry, I didn't understand that command.")

    if command and "take a screenshot" in command.lower():
        print("Taking a screenshot...")
        speak("Taking a screenshot.")
        screenshot = pyautogui.screenshot()
        screenshot.save("screenshot.png")
        speak("Screenshot saved as screenshot.png.")
        screenshot.show()

        # Save to memory buffer (not to file)
        buffered = BytesIO()
        screenshot.save(buffered, format="PNG")

        # Convert to base64 (text format)
        img_base64 = base64.b64encode(buffered.getvalue()).decode('utf-8')
        imag_path = f"[IMAGE_BASE64_START]{img_base64}"

        Insert_Data.History_Chat(command, imag_path)

    if command and "calculate" in command.lower():
       try:
           client = wolframalpha.Client(app_id)
           query = command.replace("calculate", "").strip()
           res = client.query(query)
           answer = next(res.results).text
           print(f"Calculation result: {answer}")
           speak(f"The result is {answer}")
           Insert_Data.History_Chat(command, answer)
       except Exception as e:
           print(f"Error in calculation: {e}")
           speak("Sorry, I couldn't perform the calculation. Please try again with a different query.")
           Insert_Data.History_Chat(command, "Calculation error")
    elif "what is" in command or "who is" in command or "where is" in command or "when is" in command or "how to" in command:
        try:
            client = wolframalpha.Client(app_id)
            res = client.query(command)
            answer = next(res.results).text
            print(f"Result: {answer}")
            speak(answer)
            Insert_Data.History_Chat(command, answer)
        except Exception as e:
            print(f"Error in processing command: {e}")
            speak("Sorry, I couldn't process that command. Please try again.")
            Insert_Data.History_Chat(command, "Processing error")

def listen_command():
    """Listen for a command from the microphone."""
    recognizer = sr.Recognizer()
    with sr.Microphone() as source:
        recognizer.adjust_for_ambient_noise(source)  # Adjust to ambient noise
        print("Listening...")
        try:
            audio = recognizer.listen(source, timeout=8, phrase_time_limit=5)  # Increased timeout
            command = recognizer.recognize_google(audio).lower()
            print(f"Command recognized: {command}")
            return command
        except sr.WaitTimeoutError:
            print("Listening timed out, no speech detected.")
            speak("Listening timed out, please try again.")
            return None
        except sr.UnknownValueError:
            speak("Sorry, I did not understand that.")
            return None
        except sr.RequestError as e:
            speak(f"Error with the speech service: {e}")
            return None
        except Exception as e:
            speak(f"An error occurred: {e}")
            return None

if __name__ == "__main__":
    speak("Initializing Jarvis")
    speak("Please register or unlock your account.")
    while True:
     choice = input("Do you want to (1) Register or (2) Unlock or (3) Exit? ")

     if choice == '1':
        Login_Sign_Up.sign_up()
       

     elif choice == '2':
        login = False
        login = Login_Sign_Up.login()
        if not login:
            forget = input("Do you want to reset your password? (yes/no): ").strip().lower()
            if forget == 'yes':
                username = input("Enter your username: ")
                password = input("Enter your new password: ")
                Insert_Data.forgot_password(username, password)
                print("Password updated successfully.")
                speak("Password updated successfully.")
            # else:
            #     print("Exiting...")
            #     speak("Exiting...")
            #     exit()    

        # speak("Welcome to Jarvis. How can I assist you today?")
        if login:
         speak("Welcome to Jarvis. How can I assist you today?")
         clear_screen()
         while True:
        # Listen for 'jarvis' wake word
          command = listen_command()
        # command = command.lower()
          if command and "jarvis" in command.lower():
            print("Jarvis Active")
            speak("Yes, how can I help you?")
            command = listen_command()  # Listen for the next command after 'jarvis'
            if command:
                processCommand(command)
          elif command and "exit" in command.lower():
             speak("Exiting Jarvis. Goodbye!")
             print("Exiting Jarvis. Goodbye!")
             exit()    
        

     elif choice == '3':
        speak("Goodbye. See you next time.")
        print("Goodbye!")
        exit()  

     else:
        speak("Invalid choice. Please try again.")
        print("❌ Invalid choice. Please try again.")