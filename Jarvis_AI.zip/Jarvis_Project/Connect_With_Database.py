import mysql.connector

def create_database_connection():
    """Create a database connection to the MySQL database specified by db_file"""
    conn = None
    try:
        conn = mysql.connector.connect(
            host='localhost',
            user='root',
            password='1234',  # Replace with your MySQL root password
            database='Jarvis_DB'  # Replace with your database name
        )
        # print("Connection to MySQL DB successful")
    except mysql.connector.Error as e:
        print(f"The error '{e}' occurred")
    return conn